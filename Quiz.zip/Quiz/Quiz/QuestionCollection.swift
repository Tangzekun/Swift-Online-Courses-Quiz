//
//  QuestionCollection.swift
//  Quiz
//
//  Created by TangZekun on 12/30/15.
//  Copyright © 2015 TangZekun. All rights reserved.
//

import Foundation
import UIKit

class QuestionCollection
{
    var questions : [Question]
    init()
    {
        questions  = []
        let questionImage1 : UIImage = UIImage (named: "Albert Einstein.jpg")!
        let questionImage2 : UIImage = UIImage (named: "FIFA14.jpg")!
        let questionImage3 : UIImage = UIImage (named: "Numbers.png")!
        let questionImage4 : UIImage = UIImage (named: "Valencia.jpeg")!
        let questionImage5 : UIImage = UIImage (named: "Messi.jpg")!
        let questionImage6 : UIImage = UIImage (named: "wc2002.png")!
        
        let q1 = Question(image: questionImage1, question: "Who is this person?", answerOption1: "Neo", answerOption2: "Tang", answerOption3: "Kun", answerOption4: "Alber Einstein", correctAnswerId : 4)
        questions.append(q1)
        
        let q2 = Question(image: questionImage2, question: "Which team won the Soccor World Cup 2014?", answerOption1: "China", answerOption2: "USA", answerOption3: "Germany", answerOption4: "Spain", correctAnswerId : 3)
        questions.append(q2)
        
        let q3 = Question(image: questionImage3, question: "What is the result of 4*5-12=?", answerOption1: "2", answerOption2: "4", answerOption3: "6", answerOption4: "8", correctAnswerId : 4)
        questions.append(q3)
        
        
        let q4 = Question(image: questionImage4, question: "Where is Valencia?", answerOption1: "Mexico", answerOption2: "Italy", answerOption3: "Spain", answerOption4: "France", correctAnswerId : 3)
        questions.append(q4)
        
        
        let q5 = Question(image: questionImage5, question: "Who is this soccor player?", answerOption1: "Messi", answerOption2: "Ronlado", answerOption3: "Neuer", answerOption4: "Kun", correctAnswerId : 1)
        questions.append(q5)
        
        let q6 = Question(image: questionImage6, question: "Which team won the Soccor World Cup 2002?", answerOption1: "Brazil", answerOption2: "USA", answerOption3: "Germany", answerOption4: "Spain", correctAnswerId : 1)
        questions.append(q6)
    }
    
    func getQuestions () -> [Question]
    {
        return questions
    }
    
}
