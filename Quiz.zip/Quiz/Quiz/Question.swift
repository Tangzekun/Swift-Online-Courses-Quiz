//
//  Question.swift
//  Quiz
//
//  Created by TangZekun on 12/30/15.
//  Copyright © 2015 TangZekun. All rights reserved.
//

import Foundation
import UIKit

class Question
{
    var image : UIImage!
    var question : String!
    var answerOption1 : String!
    var answerOption2 : String!
    var answerOption3 : String!
    var answerOption4 : String!
    var correctAnswerId : Int!
    
    init (image: UIImage, question: String, answerOption1: String, answerOption2: String, answerOption3: String, answerOption4: String, correctAnswerId : Int)
    {
        self.image = image
        self.question = question
        self.answerOption1 = answerOption1
        self.answerOption2 = answerOption2
        self.answerOption3 = answerOption3
        self.answerOption4 = answerOption4
        self.correctAnswerId = correctAnswerId

    }

}