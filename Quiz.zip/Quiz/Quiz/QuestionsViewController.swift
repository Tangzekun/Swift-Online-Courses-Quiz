//
//  QuestionsViewController.swift
//  Quiz
//
//  Created by TangZekun on 12/30/15.
//  Copyright © 2015 TangZekun. All rights reserved.
//

import UIKit

class QuestionsViewController: UIViewController {
    
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var answerButton1: UIButton!
    @IBOutlet weak var answerButton2: UIButton!
    @IBOutlet weak var answerButton3: UIButton!
    @IBOutlet weak var answerButton4: UIButton!
    
    var questionNumber = 0
    var answerId = 0
    var score = 0
    var questionsCollection = QuestionCollection()
    var questions = []
    var userDefaults = NSUserDefaults.standardUserDefaults()
    
    
    @IBAction func buttonPressed(sender: AnyObject)
    {
        checkCorrectess(sender.tag)
        setScore()
        questionNumber++
        nextQuestion()
        
        
    }
    
    
    func setScore()
    {
        scoreLabel.text = "Score : \(score)"
    }
    
    func setButtons()
    {
        if questionsCollection.questions.count > questionNumber
        {
            answerButton1.setTitle(questionsCollection.getQuestions()[questionsCollection.getQuestions().startIndex + questionNumber].answerOption1, forState: .Normal)
            
            answerButton2.setTitle(questionsCollection.getQuestions()[questionsCollection.getQuestions().startIndex + questionNumber].answerOption2, forState: .Normal)
            
            answerButton3.setTitle(questionsCollection.getQuestions()[questionsCollection.getQuestions().startIndex + questionNumber].answerOption3, forState: .Normal)
            
            answerButton4.setTitle(questionsCollection.getQuestions()[questionsCollection.getQuestions().startIndex + questionNumber].answerOption4, forState: .Normal)

        }
    }
    
    
    func setImage()
    {
        if questionsCollection.questions.count > questionNumber
        {
            if let questionImage = questionsCollection.getQuestions()[questionsCollection.getQuestions().startIndex + questionNumber].image
            {
                imageView.image = questionImage
            }
        }
    }
    
    
    func nextQuestion()
    {
        print("Question Number  \(questionNumber)")
        if questionsCollection.questions.count > questionNumber
        {
            questionLabel.text = questionsCollection.getQuestions()[questionsCollection.getQuestions().startIndex + questionNumber].question
        }
        setButtons()
        setImage()
        
        if questionsCollection.questions.count == questionNumber
        {
            questionLabel.text = "Quiz Over"
            saveHighScore(score)
        }
    }
    
    func checkCorrectess(answerId : Int)
    {
        if questionsCollection.questions.count > questionNumber
        {
            if answerId == questionsCollection.getQuestions()[questionsCollection.getQuestions().startIndex + questionNumber].correctAnswerId
            {
                score = score + 10
            }
        }
    }
    
    
    func saveHighScore(newScore : Int)
    {
        let highestScore = userDefaults.integerForKey("highScore")
        if highestScore <= newScore
        {
            userDefaults.setValue(newScore, forKey: "highScore")
            userDefaults.synchronize()
        }
        
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.questions = questionsCollection.getQuestions()
        setImage()
        setButtons()
        nextQuestion()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
