//
//  ViewController.swift
//  Quiz
//
//  Created by TangZekun on 12/29/15.
//  Copyright © 2015 TangZekun. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var highestScoreLabel: UILabel!
    
    let userDefaults = NSUserDefaults.standardUserDefaults()
    
    
    func setHighestScore()
    {
        if let highestScore = userDefaults.valueForKey("highestScore")
        {
            highestScoreLabel.text = "Highest Score : \(highestScore)"
        }
        
        else
        {
            highestScoreLabel.text = "No highest score yet"
        }
    }


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

